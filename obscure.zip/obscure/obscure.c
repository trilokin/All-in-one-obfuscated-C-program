/********************************************************************/
/*  Copyright (C) 2011,Trilok Inakota, <itrilok@gmail.com>          */
/*  Do not edit the file in "gedit"                                 */
/*  Open with "vim" editor				                    */
/*  Before Compilation look at README				        */
/*											  */	
/* This code is free software; you can redistribute it and/or       */ 
/* modify it under the terms of the GNU Library General Public      */ 
/* License as published by the Free Software Foundation; either     */ 
/* version 2 of the License, or (at your option) any later version. */ 
/* 											  */ 
/* This library is distributed in the hope that it will be useful,  */ 
/* but WITHOUT ANY WARRANTY; without even the implied warranty of   */ 
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU */ 
/* Library General Public License for more details.                 */ 
/********************************************************************/

%:include<stdio.h>
%:include<malloc.h>
%:include<string.h>
%:include<limits.h>
%:define S(x) putchar(x);

              struct  ext    <%        int  *c;                 %>;
              struct  ext   *(*  sTemp(int  tmp ??( ??)  ))     ??(                                11??);
typedef       struct  ext    *(* UP)??(                                                            11??);
typedef       char     *(FED);
int  *(*pTemp(int    tmp, int *(*fun2)(int,   FED fun3 ( short, UP   fun4(   int  ??( ??) ))))) ??(11??),x,
       *qTemp(short  tmp, FED    fun3( short, UP  fun4 ( int    ??(  ??)))); char   
       *rTemp(short  tmp, UP     fun4( int   ??(  ??))); struct ext  *(*sTemp(int  tmp ??(??)))??( 11??)  
       ??<    struct ext  *s                                                                    ??(11??),
/************************************************************************************************************/
                                           a,   b,   
                                         c,   d,   e,     
                                      f,    g,    h,  i,  
                                          j,    k,
/************************************************************************************************************/
*(*t)??(11??);while(!x) main(2);
                 <%a.c=&0??(tmp??),b.c=&1??(tmp??),c.c=&2??(tmp??),d.c=&3??(tmp??);%>

           0??(s??)=&a,           1??(s??)=&b,           2??(s??)=&c,           3??(s??)=&d;
                       e.c=4+tmp,             f.c=5+tmp,             g.c=6+tmp,              h.c=7+tmp;
           4??(s??)=&e,           5??(s??)=&f,           6??(s??)=&g,           7??(s??)=&h;
                       i.c=8+tmp,             j.c=9+tmp,             k.c=10+tmp;
           8??(s??)=&i,           9??(s??)=&j,           10??(s??)=&k;

t=(struct ext *(*)??(11??))s;return t;??>
/***********************************************************************************************************/
int  main( int     tmp )<% int(*t)<:11:>,i, *(*(*fun1 ??(    2??) )
         ( int         ,   int                *(*fun2 ) ( int,   FED   
                                                 fun3   ( short, UP   
                                                 fun4   ( int    ??( ??) ) ) ) ) )          ??(11??);
/***********************************************************************************************************/
                           struct  ext z??(2??), *(*s)                                      ??(11??);
if(tmp==2)<%                        S(79);     
                             S(80);      S(65);   
                        S(81);      S(85);      S(69);
                                    x=1;
return 0;%>
/************************************************************************************************************/
fun1??(0??) = pTemp;
       s    = (struct  ext  *(*)??(11??))((int (*)??(11??))fun1??(0??)(84, (int *(*)(int,char *(*)
              (short   int, struct ext *(*(*)(int *))??(11??)))) qTemp));
/***********************************************************************************************************/
                                S(64/2)for(i=0;i<11;i++)
                             S(*s??(0??)??(i??)->c)S(60/6) return 0;                           ??>
int *(*pTemp (int   tmp,  int *(*fun2)(int,FED fun3(short,UP fun4(int??(??))))))??(11??)       ??<
                   S(tmp)     return  (int   *(*)  ??(   11??))fun2(  72,   rTemp);            ??>
int   *qTemp (short tmp,  FED fun3(short , UP fun4(int ??(??))))                               ??<
             S(tmp)return (int*)  fun3(73,(struct ext *(*(*) (int *))  ??(11??)) sTemp);       ??>
char  *rTemp (short tmp,  struct ext   *(*fun4(int ??(??)))??(11??))                           ??<
                     int c??(11??)=??<80,82,79,71,82,65, 77,77,73, 78,71                       ??>;
                                 S(tmp) S(tmp+10) S(32)   S(tmp)
                                     S(tmp+10)   S(32)
                                return ((char*)((*fun4)(c)));                                  ??>
/************************************************************************************************************/



